/*****
*
*   Typical usage:
* 
*   <form> 
*   <textarea id="code" cols="40" rows="10">import turtle
*
*   t = turtle.Turtle()
*   t.forward(100)
*
*   print "Hello World" 
*   </textarea><br /> 
*   <button type="button" onclick="runit()">Run</button> 
*   </form> 
*   <pre id="output" ></pre> 
*   <div id="canvas"></div> 
*
*   <script>
*       setupPythonIDE('code','output','canvas');
*   </script>
**/

var tests;
var testinput;
var testoutput;
var testinputvisibility = 1;
var testoutputvisibility = 1;
var testresult = "" // used in index.html
var testresults = [];
var parms;
var the_skeleton;
var testsDoc;
var taskDoc;
var filesTestResults = [];
var filesTestInputs = [];
var languageCode = "lt";
var useScorm = true;
var currentInputLine = 0;
var testinputArray;
var drops;
var usedrops;
var useAI = false;
var useExplanations = false;
var useCorrections = false;
var useReviews = false;
var passing_score;
var currentHint = 0;
var hints;
var baseUrl = 'https://arzinai.lt/scormAPI/';

var stopExecutionFlag = false;

// Stops any asynchronous functions still running
var stopit = function () {
    stopExecutionFlag = true;
    document.getElementById("input_panel").style.display = "none";
}

// Capture the uncaught exception handler
// var saveUncaughtException = Sk.uncaughtException;

// Must capture the setInterval function so that processing errors
// are caught and sent to the output and so we know which asynchronous
// processes were started
var oldSetInterval = window.setInterval;
var oldSetTimeout = window.setTimeout;

var restoreAsync = function () {
    window.setInterval = setInterval = oldSetInterval;
    window.setTimeout = setTimeout = oldSetTimeout;
}

//
// Temporary functions  overwritten by setupCppIDE
//

// Runs the program loaded in the editor
var runit = function () {};

// Runs the program loaded in the editor
var evalit = function () {};

// Clears the output (both text and graphical)
var clearit = function () {};

// Sets the contents of the editor to program
var setProgram = function (program) {}

// Returns the contents of the editor
var getProgram = function () {}

// The codemirror editor
var editor;

// 
// Call this function after setting up a <textarea> for the program (id=codeId),
// a <pre> for text output (id=outputId) and a <div> for the graphical output (id = canvasId).
// It creates a codemirror-based text editor, and several functions for managing the 
// skulpt based python environment (runit,stopit,clearit,setProgram,getProgram)
//
function setupCppIDE (codeId,outputId,canvasId) {

    codeId = codeId || 'code';         // Id of a <textarea> where the code is edited
    outputId = outputId || 'output';   // Id of a <pre> tag where the output of the code is printed
    canvasId = canvasId || 'canvas';   // Id of a <div> where graphical output is to be presented

    function escapeHtmlEntities(inputString) {
      return inputString.replace(/[<>&'"]/g, function (match) {
        switch (match) {
          case '<': return '&lt;';
          case '>': return '&gt;';
          case '&': return '&amp;';
          case "'": return '&apos;';
          case '"': return '&quot;';
          default: return match;
        }
      });
    }

    // output functions are configurable.  This one just appends some text
    // to a pre element.
    function outf(text) { 
        var mypre = document.getElementById(outputId);
        mypre.style.display = "block";
        mypre.innerHTML = mypre.innerHTML + escapeHtmlEntities(text); 
    } 

    // What to use to read from input
    /*
    function builtinRead(x) {
        if (Sk.builtinFiles === undefined || Sk.builtinFiles["files"][x] === undefined)
                throw "File not found: '" + x + "'";
        return Sk.builtinFiles["files"][x];
    }
*/
    function mFileWrite(obj, stringToWrite) {
        filenameNode = document.getElementById(obj.name);
        if(!filenameNode) {
//            Sk.builtin.IOError("There is no such file!");
        }
        document.getElementById(obj.name).value += stringToWrite.v;
    }

    function mFileOpen(obj) {
        if(obj.mode.v == "w") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            }
            document.getElementById(obj.name).value = "";
        }
        if(obj.mode.v == "a") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            }
        }
        if(obj.mode.v == "x") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            } else {
//                Sk.builtin.IOError("Error. Such file already exists!");
            }
            document.getElementById(obj.name).value = "";
        }
    }

    clearit = function () {
        stopit();
        var mypre = document.getElementById(outputId); 
        mypre.innerHTML = "";   
        mypre.style.display = "none";
        var can = document.getElementById(canvasId);
        can.innerHTML = "";     
    }

    const fstream = (function() {
        const openFiles = {};

        return {
            open: function(context, fileName) {
                const openFileNode = ((context, getFileNode) => {
                    if (context.t.name === "ofstream" && !getFileNode())
                        addFileNode(fileName)
            
                    return getFileNode();
                })(context, () => document.querySelector(`textarea[id='${fileName}']`));

                openFiles[fileName] = { 
                    name: fileName,
                    _open: openFileNode != null, 
                    is_open: function() {
                        return this._open;
                    },
                    read: function(data) {
                        if (!this.is_open())
                            return;
        
                        return openFileNode.value;
                    },
                    clear: function() {
                        openFileNode.value = "";
                    },
                    write: function(data) {
                        if (!this.is_open())
                            return;
        
                        openFileNode.value += data;
                    },
                    close: function() {
                        this._open = false;
                    }
                };

                return openFiles[fileName];
            }
        };
    })();

    runit = function() { 
        errorOccured = false;

        stopit();
        clearit();

        var prog = editor.getValue(); 
        var mypre = document.getElementById(outputId); 
        mypre.innerHTML = ''; 

        var input = manualInput;
        var config = {
			fstream,
            stdio: {
                finishCallback: function(exitCode) {
                    outf("\nprogram exited with code " + exitCode);
                },
                promiseError: function(promise_error) {
                    errorOccured = true;
                    outf(promise_error);
                    showFailureAIactions();
                    stopit();  
                },
                write: function(s) {
                    outf(s);
                }
            },
            stopExecutionCheck: function() {
                return stopExecutionFlag;
            },
            //maxExecutionSteps: (100 * 100) * 10, // (lines of code * loop iterations) * 10 times buffer
            maxTimeout: 3 * 60 * 1000, // 3 mins
            eventLoopSteps: 10_000,
            unsigned_overflow: "error"
        };
        
        try {
            stopExecutionFlag = false;
            JSCPP.run(prog, input, config);
        } catch (error) {
            errorOccured = true;
            outf(error.message);
            showFailureAIactions();
            stopit();            
        }
    } 

    function getValueFromInput() {
      return new Promise((resolve, reject) => {
        const userInput = document.getElementById('input_value').value;
        resolve(userInput);
      });
    }

    function manualInput() {
        document.getElementById('input_text').innerText = "";
        document.getElementById("input_panel").style.display = "block";
        var old_element = document.getElementById("input_value");
        var new_element = old_element.cloneNode(true);
        old_element.parentNode.replaceChild(new_element, old_element);
        document.getElementById('input_value').value = "";
        document.getElementById('input_value').innerText = "";
        document.getElementById('input_value').focus();

        return new Promise((resolve, reject) => {
            document.getElementById("input_value").addEventListener("keyup", function(event) {
                if (event.keyCode === 13) {
                    document.getElementById("input_panel").style.display = "none";
                    getValueFromInput()
                        .then((value) => {
                            resolve(value);
                        })
                        .catch((error) => {
                            reject(error);
                        });
                }
            });

            document.getElementById('input_button').addEventListener('click', function(event) {
                document.getElementById("input_panel").style.display = "none";
                getValueFromInput()
                    .then((value) => {
                        resolve(value);
                    })
                    .catch((error) => {
                        reject(error);
                    });
            });
        });
    }

    function stdinInput(prompt) {
        return new Promise((resolve, reject) => {
            if(testinputArray.length > currentInputLine) {
                resolve(testinputArray[currentInputLine]);
                currentInputLine++;
            } else {
                throw new Error("Can't provide input, because where is no more input defined!");
                reject("Can't provide input, because where is no more input defined!");
            }
        });
    }

    function stdoutOutput(text) {
        return new Promise((resolve, reject) => {
            testresult = testresult + text;
            resolve(text);
        });
    }

    // Evaluation using tests
    evalit = function () { 

        errorOccured = false;

        stopit();
        clearit();

        currentInputLine = 0;
        testinputArray = testinput.split(/\r?\n/);

        var prog = editor.getValue(); 
        var mypre = document.getElementById(outputId);
        mypre.innerHTML = ''; 

        var input = stdinInput;
        var config = {
			fstream,
            stdio: {
                finishCallback: function(exitCode) {
                    registerTestResult();
                    showSuccessAIactions();            
                    proceedTests();
                },
                promiseError: function(promise_error) {
                    errorOccured = true;
                    outf(promise_error);
                    showFailureAIactions();
                    stopit();  
                },
                write: function(s) {
                    stdoutOutput(s).then((text) => outf(text));
                }
            },
            maxTimeout: 3 * 60 * 1000, // 3 mins
            eventLoopSteps: 10_000,
            unsigned_overflow: "error" 
        };
        try {
            JSCPP.run(prog, input, config);
        } catch (error) {
            errorOccured = true;
            outf(error.message);
            showFailureAIactions();
            stopit();            
        }
    } 

    //
    // Replace the textarea by a codemirror editor
    // 

    function createEditor () {
        ace.require("ace/ext/language_tools");
        editor = ace.edit("code", {
            maxLines: 25,
            wrap: true,
            autoScrollEditorIntoView: true
        });
        editor.session.setMode("ace/mode/c_cpp");
        editor.setTheme("ace/theme/monokai");
        editor.setOptions({
            enableBasicAutocompletion: true,
            enableSnippets: true,
            enableLiveAutocompletion: true
        });
    }
    createEditor ();

    // export the function to get contents of the editor
    getProgram = function () { return editor.session.getValue() };

    // export the function to set the contents of the editor
    setProgram = function (prog) { editor.session.setValue(prog); }
}
