/*****
*
*   Typical usage:
* 
*   <form> 
*   <textarea id="code" cols="40" rows="10">import turtle
*
*   t = turtle.Turtle()
*   t.forward(100)
*
*   print "Hello World" 
*   </textarea><br /> 
*   <button type="button" onclick="runit()">Run</button> 
*   </form> 
*   <pre id="output" ></pre> 
*   <div id="canvas"></div> 
*
*   <script>
*       setupPythonIDE('code','output','canvas');
*   </script>
**/


// These will hold handles to asynchronous code that skulpt sets up. We need them to
// implement the stopit function
var intervalFuncVars = [];
var timeoutFuncVars = [];

var tests;
var testinput;
var testoutput;
var testinputvisibility = 1;
var testoutputvisibility = 1;
var testresult = ""
var testresults = [];
var parms;
var the_skeleton;
var testsDoc;
var taskDoc;
var filesTestResults = [];
var filesTestInputs = [];
var languageCode = "lt";
var useScorm = true;
var currentInputLine = 0;
var testinputArray;
var drops;
var usedrops;
var useAI = false;
var useExplanations = false;
var useCorrections = false;
var useReviews = false;
var passing_score;
var currentHint = 0;
var hints;
var baseUrl = 'https://arzinai.lt/scormAPI/';

// Stops any asynchronous functions still running
var stopit = function () {
    for (var i = 0; i < intervalFuncVars.length; i++) {
        window.clearInterval (intervalFuncVars[i]);
    }
    intervalFuncVars = [];
    for (var i = 0; i < timeoutFuncVars.length; i++) {
        window.clearTimeout (timeoutFuncVars[i]);
    }
    timeoutFuncVars = [];
    document.getElementById("input_panel").style.display = "none";
}

// Capture the uncaught exception handler
var saveUncaughtException = Sk.uncaughtException;

// Must capture the setInterval function so that processing errors
// are caught and sent to the output and so we know which asynchronous
// processes were started
var oldSetInterval = window.setInterval;
var oldSetTimeout = window.setTimeout;

var restoreAsync = function () {
    window.setInterval = setInterval = oldSetInterval;
    window.setTimeout = setTimeout = oldSetTimeout;
}

//
// Temporary functions  overwritten by setupPythonIDE
//

// Runs the program loaded in the editor
var runit = function () {};

// Runs the program loaded in the editor
var evalit = function () {};

// Clears the output (both text and graphical)
var clearit = function () {};

// Sets the contents of the editor to program
var setProgram = function (program) {}

// Returns the contents of the editor
var getProgram = function () {}

// The codemirror editor
var editor;

// 
// Call this function after setting up a <textarea> for the program (id=codeId),
// a <pre> for text output (id=outputId) and a <div> for the graphical output (id = canvasId).
// It creates a codemirror-based text editor, and several functions for managing the 
// skulpt based python environment (runit,stopit,clearit,setProgram,getProgram)
//
function setupPythonIDE (codeId,outputId,canvasId) {

    codeId = codeId || 'code';         // Id of a <textarea> where the code is edited
    outputId = outputId || 'output';   // Id of a <pre> tag where the output of the code is printed
    canvasId = canvasId || 'canvas';   // Id of a <div> where graphical output is to be presented

    function escapeHtmlEntities(inputString) {
      return inputString.replace(/[<>&'"]/g, function (match) {
        switch (match) {
          case '<': return '&lt;';
          case '>': return '&gt;';
          case '&': return '&amp;';
          case "'": return '&apos;';
          case '"': return '&quot;';
          default: return match;
        }
      });
    }

    // output functions are configurable.  This one just appends some text
    // to a pre element.
    function outf(text) { 
        var mypre = document.getElementById(outputId);
        mypre.style.display = "block";
        mypre.innerHTML = mypre.innerHTML + escapeHtmlEntities(text); 
    } 

    // What to use to read from input
    function builtinRead(x) {
        if (Sk.builtinFiles === undefined || Sk.builtinFiles["files"][x] === undefined)
                throw "File not found: '" + x + "'";
        return Sk.builtinFiles["files"][x];
    }

    function mFileWrite(obj, stringToWrite) {
        filenameNode = document.getElementById(obj.name);
        if(!filenameNode) {
            Sk.builtin.IOError("There is no such file!");
        }
        document.getElementById(obj.name).value += stringToWrite.v;
    }

    function mFileOpen(obj) {
        if(obj.mode.v == "w") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            }
            document.getElementById(obj.name).value = "";
        }
        if(obj.mode.v == "a") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            }
        }
        if(obj.mode.v == "x") {
            filenameNode = document.getElementById(obj.name);
            if(!filenameNode) {
                addFileNode(obj.name);
            } else {
                Sk.builtin.IOError("Error. Such file already exists!");
            }
            document.getElementById(obj.name).value = "";
        }
    }

    // Clears outputId and canvasId
    clearit = function () {
        stopit();
        var mypre = document.getElementById(outputId); 
        mypre.innerHTML = "";   
        mypre.style.display = "none";
        var can = document.getElementById(canvasId);
        can.innerHTML = "";     
    }

    // Here's everything you need to run a python program in skulpt
    // grab the code from your textarea
    // get a reference to your pre element for output
    // configure the output function
    // call Sk.importMainWithBody()
    runit = function () { 

        errorOccured = false;

        stopit();
        clearit();

        var prog = editor.getValue(); 
        var mypre = document.getElementById(outputId); 
        mypre.innerHTML = ''; 
        Sk.pre = outputId;
        Sk.canvas = canvasId;
        var can = document.getElementById(Sk.canvas);
        can.style.display = 'table';
        if (can) {
           can.width = can.width;
           if (Sk.tg) {
               Sk.tg.canvasInit = false;
               Sk.tg.turtleList = [];
           }
        }

        // inputfun: Sk.builtin.raw_input, 
        Sk.configure({inputfun: manualInput, inputfunTakesPrompt: true, output:outf, read:builtinRead, filewrite: mFileWrite, fileopen: mFileOpen}); 
        (Sk.TurtleGraphics || (Sk.TurtleGraphics = {})).target = canvasId;


        window.setInterval = setInterval = function (f,t) {
            var handle = 
            oldSetInterval (function () {
                try {
                    f()
                } catch (err) {
                    // Report error and abort
                    restoreAsync();
                    outf(err.toString());
                    stopit();
                }
            },t);
            intervalFuncVars.push(handle);
        }


        window.setTimeout = setTimeout = function (f,t) {
            var handle = 
            oldSetTimeout (function () {
                try {
                    f();
                } catch (err) {
                    // Report error and abort
                    restoreAsync();
                    outf(err.toString());
                    stopit();
                }
            },t);
            timeoutFuncVars.push(handle);
        }

        // Capture the error message
        Sk.uncaughtException = function (e) {
            errorOccured = true;
            var msg = e.toString();
            outf(msg);
            showFailureAIactions();
            stopit();
            restoreAsync();
            saveUncaughtException(e);
        }

        var myPromise = Sk.misceval.asyncToPromise(function() {
            return Sk.importMainWithBody("<stdin>", false, prog, true);
        });

        myPromise.then(function(mod) {
        // console.log('success');
            showSuccessAIactions();
        },
           Sk.uncaughtException 
        );

        // Restore the old setInterval function
        restoreAsync();
    } 

    function getValueFromInput() {
      return new Promise((resolve, reject) => {
        const userInput = document.getElementById('input_value').value;
        resolve(userInput);
      });
    }

    function manualInput(prompt) {
        document.getElementById('input_text').innerText = prompt;
        document.getElementById("input_panel").style.display = "block";
        var old_element = document.getElementById("input_value");
        var new_element = old_element.cloneNode(true);
        old_element.parentNode.replaceChild(new_element, old_element);
        document.getElementById('input_value').value = "";
        document.getElementById('input_value').innerText = "";
        document.getElementById('input_value').focus();

        return new Promise((resolve, reject) => {
            document.getElementById("input_value").addEventListener("keyup", function(event) {
                if (event.keyCode === 13) {
                    document.getElementById("input_panel").style.display = "none";
                    getValueFromInput()
                        .then((value) => {
                            resolve(value);
                        })
                        .catch((error) => {
                            reject(error);
                        });
                }
            });

            document.getElementById('input_button').addEventListener('click', function(event) {
                document.getElementById("input_panel").style.display = "none";
                getValueFromInput()
                    .then((value) => {
                        resolve(value);
                    })
                    .catch((error) => {
                        reject(error);
                    });
            });
        });
    }

    function stdinInput(prompt) {
        return new Promise((resolve, reject) => {
            if(testinputArray.length > currentInputLine) {
                resolve(testinputArray[currentInputLine]);
                currentInputLine++;
            } else {
                reject("Can't provide input, because where is no more input defined!");
            }
        });
    }

    function stdoutOutput(text) {
        return new Promise((resolve, reject) => {
            testresult = testresult + text;
            resolve(text);
        });
    }

    // Evaluation using tests
    evalit = function () { 

        errorOccured = false;

        stopit();
        clearit();

        currentInputLine = 0;
        testinputArray = testinput.split(/\r?\n/);

        var prog = editor.getValue(); 
        var mypre = document.getElementById(outputId); 
        mypre.innerHTML = ''; 
        Sk.pre = outputId;
        Sk.canvas = canvasId;
        var can = document.getElementById(Sk.canvas);
        can.style.display = 'table';
        if (can) {
           can.width = can.width;
           if (Sk.tg) {
               Sk.tg.canvasInit = false;
               Sk.tg.turtleList = [];
           }
        }

        oldInputFun = Sk.inputfun;
        Sk.configure({inputfun: stdinInput, inputfunTakesPrompt: true, output:stdoutOutput, read:builtinRead, filewrite: mFileWrite, fileopen: mFileOpen}); 
        (Sk.TurtleGraphics || (Sk.TurtleGraphics = {})).target = canvasId;


        window.setInterval = setInterval = function (f,t) {
            var handle = 
            oldSetInterval (function () {
                try {
                    f()
                } catch (err) {
                    // Report error and abort
                    restoreAsync();
                    outf(err.toString());
                    stopit();
                }
            },t);
            intervalFuncVars.push(handle);
        }


        window.setTimeout = setTimeout = function (f,t) {
            var handle = 
            oldSetTimeout (function () {
                try {
                    f();
                } catch (err) {
                    // Report error and abort
                    restoreAsync();
                    outf(err.toString());
                    stopit();
                }
            },t);
            timeoutFuncVars.push(handle);
        }

        // Capture the error message
        Sk.uncaughtException = function (e) {
            var msg = e.toString();
            errorOccured = true;
            outf(msg);
            showFailureAIactions();
            stopit();
            restoreAsync();
            saveUncaughtException(e);
        }

        var myPromise = Sk.misceval.asyncToPromise(function() {
            return Sk.importMainWithBody("<stdin>", false, prog, true);
        });

        myPromise.then(function(mod) {
            registerTestResult();
            showSuccessAIactions();            
            Sk.configure({inputfun: oldInputFun});
            restoreAsync();
            proceedTests();
        },
            Sk.uncaughtException 
        );
    } 

    //
    // Replace the textarea by a codemirror editor
    // 
    function createEditor () {
        var textarea = document.getElementById(codeId);
        editor = CodeMirror.fromTextArea(textarea, {
            mode: {name: "python",
                   version: 3,
                   singleLineStringErrors: false
               },
            lineNumbers: true,
            viewportMargin: Infinity,
            textWrapping: true,
            indentUnit: 4,
            indentWithTabs: false,
            fontSize: "10pt",
            autoMatchParens: true,
            matchBrackets: true,
            theme: "dracula",
            extraKeys:{
                Tab: function (cm) {
                    if (cm.doc.somethingSelected()) {
                        return CodeMirror.Pass;
                    }
                    var spacesPerTab = cm.getOption("indentUnit");
                    var spacesToInsert = spacesPerTab - (cm.doc.getCursor("start").ch % spacesPerTab);    
                    var spaces = Array(spacesToInsert + 1).join(" ");
                    cm.replaceSelection(spaces, "end", "+input");
                }
            }
        });
        
    }

    createEditor ();

    // export the function to get contents of the editor
    getProgram = function () { return editor.getValue() };

    // export the function to set the contents of the editor
    setProgram = function (prog) { editor.setValue(prog); }
}
